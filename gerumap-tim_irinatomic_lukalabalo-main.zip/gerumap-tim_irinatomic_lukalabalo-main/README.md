# gerumap-tim_irinatomic_lukalabalo
gerumap-tim_irinatomic_lukalabalo created by GitHub Classroom

Luka Labalo 82/22 RN

Irina Tomic 72/22 RN

Link za Notion (specifikacije): https://www.notion.so/GeRuMap-eab3b0beb67d49fcbc4e13be62ffb474
(postavljen UML klasni dijagram u Notion)

Link za dinamicki digram (u Notion-u): https://www.notion.so/Dinamicki-dijagram-1004476b342e42c3bceea738cc2c4635
