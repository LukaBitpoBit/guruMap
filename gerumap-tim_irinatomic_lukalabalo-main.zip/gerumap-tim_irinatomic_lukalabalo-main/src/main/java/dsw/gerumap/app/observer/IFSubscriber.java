package dsw.gerumap.app.observer;

public interface IFSubscriber {
    void update(Object notification);
}
