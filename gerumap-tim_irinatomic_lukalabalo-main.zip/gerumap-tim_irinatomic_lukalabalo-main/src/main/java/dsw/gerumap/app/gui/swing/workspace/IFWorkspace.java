package dsw.gerumap.app.gui.swing.workspace;

import dsw.gerumap.app.gui.swing.workspace.view.ProjectView;
import dsw.gerumap.app.maprepository.composite.MapNode;

public interface IFWorkspace {
    ProjectView generateWorkspace();
}
