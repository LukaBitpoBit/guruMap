package dsw.gerumap.app.maprepository.mapnodefactory;

import dsw.gerumap.app.maprepository.composite.MapNode;

public interface IFMapNodeFactory {
    MapNode getNode(MapNode selectedNode);
}
