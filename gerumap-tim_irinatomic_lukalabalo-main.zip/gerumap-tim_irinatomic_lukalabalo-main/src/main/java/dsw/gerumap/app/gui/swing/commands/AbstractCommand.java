package dsw.gerumap.app.gui.swing.commands;

public abstract class AbstractCommand {

    public abstract void doCommand();
    public abstract void undoCommand();
}
